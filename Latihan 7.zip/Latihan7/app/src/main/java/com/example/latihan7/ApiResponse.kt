package com.example.latihan7

class ApiResponse {
    val data: List<User>
}